<?php
    defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!-- Page Content
================================================== -->
<div style="height: 20px;"></div>
<div>
	<p>Admin Home Page</p>
</div>
