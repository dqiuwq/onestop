<?php 
if (!defined('BASEPATH')) exit('No direct script access allowed');

class Get_admin_home extends CI_Controller {
	
	public function __construct()
	{
		parent::__construct();

		$this->load->database();
		$this->load->helper('url');

		$this->load->library('grocery_CRUD');
	}
	
	public function index()
	{
		$this->load->view('templates/admin/header');
		$this->load->view('admin_home_view');
		$this->load->view('templates/admin/footer');
	}
}

?>